
export enum MediaStatus {
  LENDO = 'Lendo',
  VOU_LER = 'Vou Ler',
  CONCLUIDO = 'Concluído',
  DROPPADO = 'Dropado',
  PAUSADO = 'Pausado',
  FAVORITO = 'Favorito'
}

export enum MediaType {
  MANGA = 'Manga',
  MANHWA = 'Manhwa',
  MANHUA = 'Manhua',
  WEBTOON = 'Webtoon',
  NOVEL = 'Novel'
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  contentUrl: any;
  pagesList?: string[];
  pages: number;
  read_at?: string;
}

export interface MangaEntry {
  id: string;
  title: string;
  type: MediaType;
  cover_url: string;
  total_chapters: number;
  current_chapter: number;
  status: MediaStatus;
  is_favorite: boolean;
  rating: number;
  chapters: Chapter[];
  pages_read: number;
}

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  avatar_url: string;
  level: number;
  xp: number;
  total_pages_read: number;
  total_chapters_read: number;
  total_titles: number;
  bio: string;
  created_at: string;
  featured_ids?: string[]; // IDs dos mangás em destaque (Top 5)
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'Comum' | 'Raro' | 'Épico' | 'Lendário' | 'Divino';
  requirement: (user: UserProfile) => boolean;
}
