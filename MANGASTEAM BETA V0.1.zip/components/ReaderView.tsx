
import React, { useEffect, useState, useRef } from 'react';
import { X, CheckCircle, BookOpen, ChevronUp, Loader2, AlertCircle, ChevronLeft, ChevronRight, Sun, ArrowRight, ArrowLeft } from 'lucide-react';
import { Chapter } from '../types';
import { storageService } from '../services/storageService';
import * as pdfjsLib from 'pdfjs-dist';
import JSZip from 'jszip';

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://esm.sh/pdfjs-dist@4.10.38/build/pdf.worker.min.mjs`;

interface ReaderProps {
  mangaTitle: string;
  chapter: Chapter;
  onClose: () => void;
  onComplete: (pages: number) => void;
  onNext?: () => void;
  onPrev?: () => void;
  hasNext?: boolean;
  hasPrev?: boolean;
}

const ReaderView: React.FC<ReaderProps> = ({ mangaTitle, chapter, onClose, onComplete, onNext, onPrev, hasNext, hasPrev }) => {
  const [loading, setLoading] = useState(true);
  const [renderProgress, setRenderProgress] = useState({ current: 0, total: 0 });
  const [error, setError] = useState<string | null>(null);
  const [pages, setPages] = useState<string[]>([]);
  const [brightness, setBrightness] = useState(100);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [showSideControls, setShowSideControls] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    const progress = (target.scrollTop / (target.scrollHeight - target.clientHeight)) * 100;
    setScrollProgress(progress);
  };

  useEffect(() => {
    let isMounted = true;
    const blobUrls: string[] = [];

    // Protocolo de Reset de Scroll: Volta ao topo sempre que o capítulo muda
    if (containerRef.current) {
      containerRef.current.scrollTop = 0;
    }
    
    const extractCbz = async (blob: Blob) => {
      try {
        const zip = await JSZip.loadAsync(blob);
        const imageFiles = Object.keys(zip.files)
          .filter(name => /\.(jpe?g|png|webp|avif)$/i.test(name))
          .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));

        if (isMounted) setRenderProgress({ current: 0, total: imageFiles.length });

        const extractedUrls: string[] = [];
        for (let i = 0; i < imageFiles.length; i++) {
          if (!isMounted) break;
          const fileData = await zip.files[imageFiles[i]].async('blob');
          const url = URL.createObjectURL(fileData);
          extractedUrls.push(url);
          blobUrls.push(url);
          
          if (i % 5 === 0 || i === imageFiles.length - 1) {
             setPages([...extractedUrls]);
          }
          setRenderProgress({ current: i + 1, total: imageFiles.length });
        }
        setLoading(false);
      } catch (err) {
        throw new Error("Erro ao extrair pacote CBZ. Verifique se o arquivo está íntegro.");
      }
    };

    const renderPdf = async (blob: Blob) => {
      try {
        const arrayBuffer = await blob.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        if (isMounted) setRenderProgress({ current: 0, total: pdf.numPages });

        const localUrls: string[] = [];
        for (let i = 1; i <= pdf.numPages; i++) {
          if (!isMounted) break;
          const page = await pdf.getPage(i);
          const viewport = page.getViewport({ scale: 1.5 });
          const canvas = document.createElement('canvas');
          const context = canvas.getContext('2d');
          if (context) {
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            await page.render({ canvasContext: context, viewport, canvas: canvas }).promise;
            const pageBlob = await new Promise<Blob | null>(res => canvas.toBlob(res, 'image/webp', 0.8));
            if (pageBlob && isMounted) {
              const url = URL.createObjectURL(pageBlob);
              localUrls.push(url);
              blobUrls.push(url);
              if (i === 1) setLoading(false);
              setPages([...localUrls]);
            }
          }
          setRenderProgress({ current: i, total: pdf.numPages });
        }
      } catch (err) {
        throw new Error("Falha no processamento do Protocolo PDF.");
      }
    };

    const loadContent = async () => {
      setLoading(true);
      setError(null);
      setPages([]);
      
      try {
        const data = await storageService.getChapterData(chapter.id);
        if (!data) throw new Error("Dossier não localizado na memória flash.");

        const content = data.contentUrl;
        const isPdf = (content instanceof Blob && content.type === 'application/pdf') || 
                      (typeof content === 'string' && content.includes('application/pdf'));
        const isCbz = (content instanceof Blob && ((content as any).name?.endsWith('.cbz') || content.type === 'application/x-cbz' || content.type === 'application/zip'));

        if (isCbz) {
          await extractCbz(content as Blob);
        } else if (isPdf) {
          let blob = content;
          if (typeof content === 'string') {
            const res = await fetch(content);
            blob = await res.blob();
          }
          await renderPdf(blob as Blob);
        } else {
          if (data.pagesList && data.pagesList.length > 0) {
            setPages(data.pagesList);
          } else if (content) {
            setPages([content]);
          }
          setLoading(false);
        }
      } catch (err: any) {
        if (isMounted) setError(err.message || "Erro desconhecido no subsistema de renderização.");
        setLoading(false);
      }
    };

    loadContent();
    
    return () => {
      isMounted = false;
      blobUrls.forEach(url => URL.revokeObjectURL(url));
    };
  }, [chapter.id]);

  return (
    <div 
      className="fixed inset-0 z-[100] bg-[#07090e] flex flex-col animate-in fade-in duration-300"
      onMouseMove={() => setShowSideControls(true)}
      onMouseLeave={() => setShowSideControls(false)}
    >
      <div className={`fixed left-4 top-1/2 -translate-y-1/2 z-[150] transition-opacity duration-300 ${showSideControls && hasPrev ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
         <button onClick={onPrev} className="p-4 bg-white/5 hover:bg-blue-600 backdrop-blur-md rounded-full border border-white/10 text-white shadow-2xl transition-all"><ArrowLeft size={24} /></button>
      </div>

      <div className={`fixed right-4 top-1/2 -translate-y-1/2 z-[150] transition-opacity duration-300 ${showSideControls && hasNext ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
         <button onClick={onNext} className="p-4 bg-white/5 hover:bg-blue-600 backdrop-blur-md rounded-full border border-white/10 text-white shadow-2xl transition-all"><ArrowRight size={24} /></button>
      </div>

      <div className="fixed top-0 left-0 w-full h-1 bg-white/5 z-[120]">
        <div className="h-full bg-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.5)] transition-all duration-300" style={{ width: `${scrollProgress}%` }} />
      </div>

      <header className="p-4 bg-[#11141b]/95 backdrop-blur-md border-b border-white/5 flex items-center justify-between sticky top-0 z-[110] shadow-2xl">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-xl text-gray-400 transition-colors"><X /></button>
          <div>
            <h2 className="text-sm font-black text-white uppercase italic tracking-tighter truncate max-w-[150px]">{mangaTitle}</h2>
            <p className="text-[10px] text-blue-500 font-bold uppercase tracking-widest">Protocolo: Cap {chapter.number} {loading ? `(Extraindo: ${renderProgress.current}/${renderProgress.total})` : ''}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center bg-black/40 rounded-xl border border-white/5 p-1 px-3 gap-3">
             <Sun size={14} className="text-gray-600" />
             <input type="range" min="30" max="100" value={brightness} onChange={(e) => setBrightness(parseInt(e.target.value))} className="w-16 h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-blue-500" />
          </div>
          <button onClick={() => onComplete(pages.length)} className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-2.5 rounded-xl font-black text-[10px] uppercase shadow-xl shadow-blue-600/20 italic">Finalizar</button>
        </div>
      </header>

      <div 
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto bg-black scroll-smooth custom-reader-scroll"
        style={{ filter: `brightness(${brightness}%)` }}
      >
        {loading && pages.length === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0b0e14]">
             <Loader2 size={56} className="text-blue-500 animate-spin mb-4" />
             <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.5em] animate-pulse">Extraindo Dados...</p>
          </div>
        )}

        {error && (
          <div className="flex flex-col items-center justify-center py-60 text-center px-10">
            <AlertCircle size={48} className="text-red-500 mb-6" />
            <h3 className="text-3xl font-black text-white italic uppercase tracking-tighter">Erro de Protocolo</h3>
            <p className="text-gray-500 text-sm mt-4 max-w-sm font-bold uppercase tracking-widest">{error}</p>
          </div>
        )}

        <div className="w-full max-w-[900px] mx-auto min-h-screen bg-black">
          <div className="flex flex-col w-full">
            {pages.map((url, idx) => (
              <img key={idx} src={url} alt={`Página ${idx + 1}`} className="w-full h-auto block" loading={idx < 3 ? "eager" : "lazy"} />
            ))}
          </div>

          {!loading && !error && (
            <div className="py-32 flex flex-col items-center gap-12 bg-gradient-to-t from-blue-900/20 to-black">
               <div className="text-center space-y-4">
                  <CheckCircle size={40} className="text-blue-500 mx-auto" />
                  <h4 className="text-4xl font-black text-white italic uppercase tracking-tighter">Capítulo {chapter.number} Concluído</h4>
                  <button onClick={() => onComplete(pages.length)} className="bg-blue-600 text-white px-24 py-7 rounded-full font-black uppercase tracking-[0.3em] shadow-2xl hover:scale-105 transition-all italic">Confirmar Leitura</button>
               </div>
            </div>
          )}
        </div>
      </div>
      <style>{`.custom-reader-scroll::-webkit-scrollbar { width: 10px; } .custom-reader-scroll::-webkit-scrollbar-track { background: #000; } .custom-reader-scroll::-webkit-scrollbar-thumb { background: #1a1d23; border: 2px solid #000; border-radius: 10px; } .custom-reader-scroll::-webkit-scrollbar-thumb:hover { background: #3b82f6; }`}</style>
    </div>
  );
};

export default ReaderView;
