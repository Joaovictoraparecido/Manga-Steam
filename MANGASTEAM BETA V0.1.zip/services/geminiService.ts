
import { GoogleGenAI, Type } from "@google/genai";

// Always use the environment variable directly for the API key
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const MangaAIService = {
  async getMangaSuggestions(currentLibrary: string[]) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Based on this library: ${currentLibrary.join(', ')}, suggest 3 similar manga/manhwa. Provide title and a very brief pitch.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                pitch: { type: Type.STRING }
              },
              propertyOrdering: ["title", "pitch"]
            }
          }
        }
      });
      // Access the .text property directly and trim before parsing
      const jsonStr = response.text?.trim() || '[]';
      return JSON.parse(jsonStr);
    } catch (error) {
      console.error("Gemini Error:", error);
      return [];
    }
  },

  async summarizePlot(mangaTitle: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide a cool, "Steam-style" game description for the manga "${mangaTitle}". Use epic tone.`,
      });
      // Access the .text property directly
      return response.text || "No summary available.";
    } catch (error) {
      console.error("Gemini Summarization Error:", error);
      return "Unable to generate summary.";
    }
  }
};
