
import React from 'react';
import { Database, Shield, Layout, Zap, DollarSign, Repeat, ArrowUpCircle } from 'lucide-react';

const ArchitectureSpecs: React.FC = () => {
  return (
    <div className="space-y-12 max-w-5xl mx-auto pb-20">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-black text-white tracking-tighter">System Blueprint</h1>
        <p className="text-gray-400 text-lg max-w-2xl mx-auto">Scalable architecture for a high-performance reader-centric SaaS platform.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <SpecCard 
          icon={<Zap className="text-yellow-400" />} 
          title="Technology Stack"
          items={[
            "Frontend: React 18 + TypeScript + Tailwind CSS",
            "State Management: React Context + Supabase Hooks",
            "Backend: Supabase (Serverless/PostgreSQL)",
            "AI Layer: Gemini 3 Flash (Metadata & Recommendations)",
            "Analytics: Recharts (Progress Visualization)"
          ]}
        />
        <SpecCard 
          icon={<Database className="text-blue-400" />} 
          title="Data Modeling"
          items={[
            "Profiles: User metadata, XP, Level, Streaks",
            "MangaMetadata: Global cache for titles (no binary content)",
            "UserLibrary: Many-to-Many join with status tracking",
            "ReadingHistory: Detailed log for chapter stats",
            "Achievements: Gamified triggers & rarity definitions"
          ]}
        />
        <SpecCard 
          icon={<Shield className="text-green-400" />} 
          title="Security & Escalability"
          items={[
            "Auth: Supabase Auth (OAuth + JWT)",
            "Permissions: Row Level Security (RLS) for data privacy",
            "Metadata-only: Zero risk of copyright infringement",
            "API Caching: Global CDN for cover images",
            "Serverless: Auto-scaling functions for progress logging"
          ]}
        />
        <SpecCard 
          icon={<DollarSign className="text-emerald-400" />} 
          title="Monetization (Freemium)"
          items={[
            "Free: Track up to 50 active titles, basic stats",
            "Premium: Unlimited library, custom profiles, ad-free",
            "Digital Goods: Cosmetic frames and rare badges",
            "Sponsorships: Verified badges for scanlator groups",
            "Supporter Tier: Priority AI recommendations"
          ]}
        />
      </div>

      <div className="bg-[#1a1d23] border border-[#2d3748] rounded-3xl p-10">
        <h2 className="text-3xl font-black text-white mb-8 flex items-center gap-3">
          <Repeat className="text-purple-500" /> Retention & Growth Strategy
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-3">
            <h4 className="text-blue-400 font-bold uppercase text-xs tracking-widest">Psychology</h4>
            <h3 className="text-xl font-bold text-white">Loss Aversion</h3>
            <p className="text-gray-400 text-sm">Streaks and daily goals create a ritual that users are afraid to break, increasing Daily Active Users (DAU).</p>
          </div>
          <div className="space-y-3">
            <h4 className="text-purple-400 font-bold uppercase text-xs tracking-widest">Social</h4>
            <h3 className="text-xl font-bold text-white">Social Proof</h3>
            <p className="text-gray-400 text-sm">Global rankings and public profiles with rare achievements motivate users to read more and share progress.</p>
          </div>
          <div className="space-y-3">
            <h4 className="text-orange-400 font-bold uppercase text-xs tracking-widest">Utility</h4>
            <h3 className="text-xl font-bold text-white">Value Retention</h3>
            <p className="text-gray-400 text-sm">Centralized library acts as a permanent record. Even if a scan site dies, the progress remains safe here.</p>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 rounded-3xl p-8 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <ArrowUpCircle size={48} className="text-blue-500" />
          <div>
            <h3 className="text-2xl font-bold text-white">Ready for Production Expansion</h3>
            <p className="text-gray-300">Future roadmap includes Anime tracking integration and Light Novel support.</p>
          </div>
        </div>
        <button className="bg-blue-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-blue-700 transition-all shadow-xl">
          View Roadmap
        </button>
      </div>
    </div>
  );
};

const SpecCard: React.FC<{ icon: React.ReactNode, title: string, items: string[] }> = ({ icon, title, items }) => (
  <div className="bg-[#1a1d23] border border-[#2d3748] rounded-3xl p-8 hover:bg-[#1a1d23]/80 transition-all">
    <div className="flex items-center gap-4 mb-6">
      <div className="p-3 bg-[#0b0e14] rounded-2xl border border-[#2d3748]">
        {icon}
      </div>
      <h3 className="text-2xl font-bold text-white">{title}</h3>
    </div>
    <ul className="space-y-4">
      {items.map((item, idx) => (
        <li key={idx} className="flex items-start gap-3 text-gray-400">
          <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
          <span className="text-sm leading-relaxed">{item}</span>
        </li>
      ))}
    </ul>
  </div>
);

export default ArchitectureSpecs;
