
import React from 'react';
import { Clock, Play, Plus, LayoutGrid, Target, Flame, Trophy, Hash, BookOpen, Database } from 'lucide-react';
import { UserProfile, MangaEntry, Chapter } from '../types';
import { getRankInfo } from '../constants';

interface DashboardProps {
  user: UserProfile;
  library: MangaEntry[];
  onRead: (mangaId: string, chapter: Chapter) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, library, onRead }) => {
  const reading = library.filter(m => m.status === 'Lendo').slice(0, 4);
  const rank = getRankInfo(user.total_chapters_read);

  return (
    <div className="space-y-12 animate-in fade-in duration-700 pb-20">
      {/* Hero Welcome */}
      <section className="relative h-72 rounded-[3.5rem] overflow-hidden border border-white/5 shadow-2xl group">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-[#11141b] to-black" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent" />
        <div className="absolute bottom-12 left-12 flex flex-col gap-3">
          <div className="flex items-center gap-3">
             <span className="bg-blue-600 text-white text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-[0.2em] italic shadow-lg shadow-blue-600/30">Operativo Ativo</span>
             <div className="h-1 w-1 bg-white rounded-full animate-pulse" />
          </div>
          <h2 className="text-6xl font-black text-white italic tracking-tighter uppercase leading-none">SEJA BEM-VINDO, <span className="text-blue-500">{user.username}</span></h2>
          <p className="text-gray-400 font-bold uppercase text-[10px] tracking-[0.3em] max-w-xl">Sistema operacional sincronizado. Aguardando próximas diretivas de leitura.</p>
        </div>
      </section>

      {/* Grid Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatTile 
          icon={<Trophy size={18} />} 
          label="Nível do Operativo" 
          value={user.level.toString()} 
          sub={rank.title} 
          color="blue" 
        />
        <StatTile 
          icon={<Hash size={18} />} 
          label="Capítulos Processados" 
          value={user.total_chapters_read.toString()} 
          sub="Total Intel" 
          color="purple" 
        />
        <StatTile 
          icon={<BookOpen size={18} />} 
          label="Páginas Coletadas" 
          value={user.total_pages_read.toString()} 
          sub="Dados Analisados" 
          color="green" 
        />
        <StatTile 
          icon={<Database size={18} />} 
          label="Títulos na Base" 
          value={user.total_titles.toString()} 
          sub="Séries Adicionadas" 
          color="orange" 
        />
      </div>

      {/* Resume Reading */}
      <section className="space-y-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Target className="text-blue-500" size={28} />
            <h2 className="text-3xl font-black text-white italic tracking-tighter uppercase">Missões em Andamento</h2>
          </div>
        </div>

        {reading.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {reading.map((m) => {
              const nextCap = m.chapters.find(c => c.number === m.current_chapter + 1) || m.chapters[0];
              return (
                <div key={m.id} className="bg-[#11141b] rounded-[2.5rem] overflow-hidden border border-white/5 group hover:border-blue-500/30 transition-all shadow-2xl">
                  <div className="relative aspect-[3/4] overflow-hidden">
                    <img src={m.cover_url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent" />
                    <div className="absolute bottom-5 left-5 right-5">
                       <p className="text-blue-500 font-black text-[10px] uppercase tracking-widest mb-1 italic">Próximo: Cap {m.current_chapter + 1}</p>
                       <h3 className="font-black text-white truncate text-xl uppercase italic tracking-tighter">{m.title}</h3>
                    </div>
                  </div>
                  <div className="p-6">
                    <button 
                      onClick={() => nextCap && onRead(m.id, nextCap)}
                      disabled={!nextCap}
                      className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white font-black py-4 rounded-2xl text-[10px] uppercase tracking-widest transition-all shadow-xl shadow-blue-600/20 italic flex items-center justify-center gap-2"
                    >
                      <Play size={14} fill="currentColor" /> Retomar Missão
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-32 bg-[#11141b]/50 border-2 border-dashed border-white/5 rounded-[3rem] flex flex-col items-center justify-center gap-6 text-gray-700">
            <LayoutGrid size={56} className="opacity-20" />
            <p className="font-black text-xs uppercase tracking-[0.4em] opacity-30 italic">Nenhuma missão ativa no momento</p>
          </div>
        )}
      </section>
    </div>
  );
};

const StatTile: React.FC<{ label: string, value: string, sub: string, color: string, icon: React.ReactNode }> = ({ label, value, sub, color, icon }) => {
  const c = color === 'blue' ? 'text-blue-500' : color === 'purple' ? 'text-purple-500' : color === 'orange' ? 'text-orange-500' : 'text-green-500';
  const bg = color === 'blue' ? 'bg-blue-500/10' : color === 'purple' ? 'bg-purple-500/10' : color === 'orange' ? 'bg-orange-500/10' : 'bg-green-500/10';
  
  return (
    <div className="bg-[#11141b] p-8 rounded-[2.5rem] border border-white/5 shadow-2xl group hover:border-white/10 transition-all">
      <div className="flex items-center justify-between mb-4">
        <p className="text-[9px] font-black uppercase tracking-[0.3em] text-gray-600">{label}</p>
        <div className={`${bg} ${c} p-2 rounded-xl border border-white/5 shadow-inner`}>
          {icon}
        </div>
      </div>
      <div className="flex items-baseline gap-3">
        <span className={`text-4xl font-black italic tracking-tighter ${c}`}>{value}</span>
        <span className="text-[9px] font-bold text-gray-700 uppercase tracking-widest">{sub}</span>
      </div>
    </div>
  );
};

export default Dashboard;
