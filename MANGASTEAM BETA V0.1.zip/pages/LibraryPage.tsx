
import React, { useState, useMemo } from 'react';
import { 
  PlusCircle, 
  Upload, 
  BookOpen, 
  ArrowLeft, 
  Loader2, 
  CheckCircle2, 
  Edit3, 
  Trash2, 
  X, 
  Heart, 
  Layers, 
  Filter, 
  Save, 
  FileEdit,
  Settings2,
  AlertTriangle,
  RotateCcw,
  FileSearch,
  FilePlus2,
  FolderOpen,
  LayoutList,
  Check
} from 'lucide-react';
import { MangaEntry, MediaStatus, MediaType, Chapter } from '../types';
import { storageService } from '../services/storageService';

interface LibraryPageProps {
  library: MangaEntry[];
  onAddChapter: (mangaId: string, chapter: Omit<Chapter, 'id'>) => void;
  onUpdateManga: (mangaId: string, updates: Partial<MangaEntry>) => void;
  onDeleteManga: (mangaId: string) => void;
  onDeleteChapter: (mangaId: string, chapterId: string) => void;
  onRead: (mangaId: string, chapter: Chapter) => void;
}

const LibraryPage: React.FC<LibraryPageProps> = ({ library, onAddChapter, onUpdateManga, onDeleteManga, onDeleteChapter, onRead }) => {
  const [filter, setFilter] = useState<MediaStatus | 'Todos'>('Todos');
  const [typeFilter, setTypeFilter] = useState<MediaType | 'Todos'>('Todos');
  const [selectedMangaId, setSelectedMangaId] = useState<string | null>(null);
  const [showCapModal, setShowCapModal] = useState(false);
  const [uploadMode, setUploadMode] = useState<'single' | 'bulk'>('single');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processProgress, setProcessProgress] = useState(0);
  
  const [newCap, setNewCap] = useState<{number: number, title: string, contentUrl: any, pages: number, pagesList?: string[]}>({ 
    number: 1, title: '', contentUrl: null, pages: 1, pagesList: [] 
  });

  const activeManga = useMemo(() => library.find(m => m.id === selectedMangaId) || null, [library, selectedMangaId]);

  const filtered = library.filter(m => 
    (filter === 'Todos' || m.status === filter) &&
    (typeFilter === 'Todos' || m.type === typeFilter)
  );

  const isSpecialFile = (file: File) => {
    const name = file.name.toLowerCase();
    return file.type === 'application/pdf' || 
           name.endsWith('.pdf') || 
           name.endsWith('.cbz') || 
           name.endsWith('.zip') || 
           file.type === 'application/x-cbz' || 
           file.type === 'application/zip';
  };

  const extractChapterNumber = (name: string): number | null => {
    const match = name.match(/\d+(\.\d+)?/);
    return match ? parseFloat(match[0]) : null;
  };

  const processSingleFiles = async (files: FileList) => {
    setIsProcessing(true);
    try {
      const fileList = Array.from(files);
      const firstFile = fileList[0];

      if (fileList.length === 1 && isSpecialFile(firstFile)) {
        setNewCap(prev => ({ ...prev, contentUrl: firstFile, pages: 1, pagesList: [] }));
      } else {
        fileList.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
        const promises = fileList.map(file => {
          return new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.readAsDataURL(file);
          });
        });
        const results = await Promise.all(promises);
        setNewCap(prev => ({ ...prev, contentUrl: results[0] || '', pagesList: results, pages: results.length }));
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const processBulkFolder = async (files: FileList) => {
    if (!activeManga) return;
    setIsProcessing(true);
    setProcessProgress(0);

    try {
      const allFiles = Array.from(files);
      const groups: Record<string, File[]> = {};
      
      allFiles.forEach(file => {
        const pathParts = file.webkitRelativePath.split('/');
        const isSpecial = isSpecialFile(file);
        
        if (pathParts.length > 2) {
          // Arquivo dentro de subpasta (ex: Manga/Cap 1/img.jpg ou Manga/Cap 1/c1.pdf)
          const folderName = pathParts[pathParts.length - 2];
          if (!groups[folderName]) groups[folderName] = [];
          groups[folderName].push(file);
        } else if (pathParts.length === 2 && isSpecial) {
          // Arquivo especial na raiz da pasta selecionada (ex: Manga/Cap 1.cbz)
          const fileName = pathParts[pathParts.length - 1].replace(/\.[^/.]+$/, "");
          if (!groups[fileName]) groups[fileName] = [];
          groups[fileName].push(file);
        }
      });

      const folderNames = Object.keys(groups).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
      const totalGroups = folderNames.length;

      for (let i = 0; i < totalGroups; i++) {
        const folderName = folderNames[i];
        const chapterFiles = groups[folderName];
        
        // Verifica se há um arquivo especial (PDF/CBZ) neste grupo
        const specialFile = chapterFiles.find(f => isSpecialFile(f));
        
        let contentToSave: any;
        let finalPagesList: string[] = [];
        let finalPagesCount: number = 0;

        if (specialFile) {
          contentToSave = specialFile;
          finalPagesCount = 1;
        } else {
          const sortedImgs = chapterFiles
            .filter(f => f.type.startsWith('image/'))
            .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
          
          if (sortedImgs.length === 0) continue;

          const promises = sortedImgs.map(file => {
            return new Promise<string>((resolve) => {
              const reader = new FileReader();
              reader.onloadend = () => resolve(reader.result as string);
              reader.readAsDataURL(file);
            });
          });

          const results = await Promise.all(promises);
          contentToSave = results[0];
          finalPagesList = results;
          finalPagesCount = results.length;
        }

        const num = extractChapterNumber(folderName) || (activeManga.chapters.length + i + 1);
        
        await onAddChapter(activeManga.id, {
          number: num,
          title: folderName,
          contentUrl: contentToSave,
          pagesList: finalPagesList,
          pages: finalPagesCount
        });

        setProcessProgress(Math.round(((i + 1) / totalGroups) * 100));
      }

      setShowCapModal(false);
    } catch (err) {
      console.error("Erro no processamento em massa:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAddSingleChapter = () => {
    if (activeManga) {
      onAddChapter(activeManga.id, newCap);
      setShowCapModal(false);
      setNewCap({ number: activeManga.chapters.length + 1, title: '', contentUrl: null, pages: 1, pagesList: [] });
    }
  };

  const sortedChapters = activeManga ? [...activeManga.chapters].sort((a, b) => a.number - b.number) : [];

  return (
    <div className="space-y-6 lg:space-y-12 animate-in fade-in duration-500 pb-10">
      <header>
        <h1 className="text-3xl lg:text-5xl font-black text-white italic uppercase tracking-tighter">Minha Estante</h1>
        <p className="text-gray-500 font-bold uppercase text-[9px] lg:text-[10px] tracking-widest mt-1 lg:mt-2">Acervo Offline Detectado</p>
      </header>

      {/* Filtros */}
      <div className="space-y-4 overflow-x-auto pb-2 scrollbar-hide">
        <div className="flex gap-2 min-w-max">
          {['Todos', ...Object.values(MediaStatus)].map((s) => (
            <button key={s} onClick={() => setFilter(s as any)} className={`px-4 lg:px-8 py-2 lg:py-3 rounded-xl lg:rounded-2xl text-[10px] lg:text-[11px] font-black uppercase tracking-widest transition-all ${filter === s ? 'bg-blue-600 text-white shadow-xl' : 'bg-[#11141b] text-gray-500 border border-white/5'}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Grid de Mangás */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 lg:gap-10">
        {filtered.map((item) => (
          <div key={item.id} onClick={() => setSelectedMangaId(item.id)} className="group cursor-pointer">
            <div className="relative aspect-[3/4] rounded-[2rem] lg:rounded-[3.5rem] overflow-hidden mb-3 lg:mb-6 border-2 lg:border-4 border-white/5 shadow-2xl group-hover:scale-105 transition-all duration-500">
              <img src={item.cover_url} className="w-full h-full object-cover" />
              <div className="absolute top-3 lg:top-6 left-3 lg:left-6 bg-blue-600 text-[8px] lg:text-[10px] font-black px-2 lg:px-4 py-1 rounded-lg lg:rounded-xl uppercase italic shadow-2xl">{item.type}</div>
            </div>
            <div className="px-2">
               <h3 className="font-black text-white truncate text-xs lg:text-lg uppercase italic tracking-tighter leading-none">{item.title}</h3>
               <p className="text-[9px] lg:text-[10px] text-gray-500 font-bold uppercase mt-1">Cap: {item.current_chapter}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Drawer de Gestão do Mangá */}
      {activeManga && (
        <div className="fixed inset-0 z-[60] flex items-center justify-end bg-black/95 backdrop-blur-xl p-0 lg:p-6" onClick={() => setSelectedMangaId(null)}>
           <div className="w-full lg:max-w-2xl h-full bg-[#0b0e14] rounded-none lg:rounded-[4rem] border-0 lg:border-2 border-white/10 p-6 lg:p-12 overflow-y-auto animate-in slide-in-from-right" onClick={e => e.stopPropagation()}>
              
              <div className="flex items-center justify-between mb-8 lg:mb-12">
                <button onClick={() => setSelectedMangaId(null)} className="text-gray-500 hover:text-white flex items-center gap-2 font-black text-xs uppercase italic">
                   <ArrowLeft size={16}/> Voltar para Estante
                </button>
                <div className="flex gap-2">
                   <button onClick={() => setShowCapModal(true)} className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase italic flex items-center gap-2 shadow-xl shadow-blue-600/20"><PlusCircle size={16}/> Adicionar Capítulos</button>
                   <button onClick={() => onDeleteManga(activeManga.id)} className="p-3 bg-red-600/10 text-red-500 rounded-2xl border border-red-500/20"><Trash2 size={18}/></button>
                </div>
              </div>

              <div className="bg-[#11141b] p-6 lg:p-10 rounded-[2.5rem] lg:rounded-[3.5rem] border border-white/5 mb-8 lg:mb-12">
                 <div className="flex flex-col lg:flex-row gap-6 lg:gap-10">
                    <img src={activeManga.cover_url} className="w-full lg:w-44 aspect-[3/4] rounded-[2rem] object-cover border border-white/10 shadow-2xl" />
                    <div className="space-y-4">
                       <h2 className="text-2xl lg:text-4xl font-black text-white italic uppercase tracking-tighter leading-none">{activeManga.title}</h2>
                       <div className="flex gap-2">
                          <span className="bg-blue-600 text-white px-4 py-1 rounded-lg text-[9px] font-black uppercase italic">{activeManga.type}</span>
                          <span className="bg-white/5 text-gray-400 border border-white/10 px-4 py-1 rounded-lg text-[9px] font-black uppercase italic">{activeManga.status}</span>
                       </div>
                    </div>
                 </div>
              </div>

              <div className="space-y-6">
                 <h3 className="text-xl lg:text-2xl font-black text-white italic tracking-tighter uppercase flex items-center gap-3"><BookOpen size={24} className="text-blue-600" /> Registro de Episódios</h3>
                 <div className="space-y-3 pb-20">
                    {sortedChapters.map(cap => (
                      <div key={cap.id} className="flex items-center justify-between p-4 bg-[#11141b] rounded-2xl border border-white/5 hover:border-blue-500/30 transition-all group">
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-black rounded-xl flex items-center justify-center font-black italic text-blue-500 border border-white/5 text-sm">
                               {cap.number}
                            </div>
                            <div>
                               <p className="text-white font-black text-xs uppercase italic truncate max-w-[150px]">{cap.title || `Capítulo ${cap.number}`}</p>
                               {cap.read_at && <p className="text-[8px] text-green-500 font-bold uppercase tracking-widest mt-0.5">Lido em {new Date(cap.read_at).toLocaleDateString()}</p>}
                            </div>
                         </div>
                         <div className="flex items-center gap-2">
                            <button onClick={() => onDeleteChapter(activeManga.id, cap.id)} className="p-2 text-gray-700 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"><Trash2 size={14}/></button>
                            <button onClick={() => onRead(activeManga.id, cap)} className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-[10px] font-black uppercase italic transition-all shadow-lg shadow-blue-600/10">Ler</button>
                         </div>
                      </div>
                    ))}
                    {sortedChapters.length === 0 && (
                      <div className="py-20 text-center border-2 border-dashed border-white/5 rounded-3xl">
                         <p className="text-gray-600 font-black text-[10px] uppercase tracking-widest italic">Nenhum capítulo disponível</p>
                      </div>
                    )}
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* Modal de Adição de Capítulos (Single & Bulk) */}
      {showCapModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 lg:p-6 bg-black/95 backdrop-blur-xl">
           <div className="bg-[#11141b] w-full max-w-2xl rounded-[3rem] border border-white/5 shadow-2xl p-8 lg:p-12 space-y-8 overflow-y-auto max-h-[90vh] custom-reader-scroll">
              <div className="flex items-center justify-between">
                 <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter">Injetar Conteúdo</h2>
                 <button onClick={() => !isProcessing && setShowCapModal(false)} className="text-gray-500 hover:text-white"><X size={24}/></button>
              </div>

              {/* Seletor de Modo */}
              <div className="flex p-1 bg-[#0b0e14] rounded-2xl border border-white/5">
                 <button 
                  onClick={() => setUploadMode('single')}
                  className={`flex-1 py-3 rounded-xl font-black text-[10px] uppercase italic tracking-widest flex items-center justify-center gap-2 transition-all ${uploadMode === 'single' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-600'}`}
                 >
                   <FilePlus2 size={14}/> Capítulo Único
                 </button>
                 <button 
                  onClick={() => setUploadMode('bulk')}
                  className={`flex-1 py-3 rounded-xl font-black text-[10px] uppercase italic tracking-widest flex items-center justify-center gap-2 transition-all ${uploadMode === 'bulk' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-600'}`}
                 >
                   <FolderOpen size={14}/> Upload de Pasta
                 </button>
              </div>

              {isProcessing ? (
                <div className="py-16 flex flex-col items-center justify-center gap-6">
                   <div className="relative">
                      <Loader2 size={64} className="text-blue-500 animate-spin" />
                      <div className="absolute inset-0 flex items-center justify-center text-[10px] font-black text-white">{processProgress}%</div>
                   </div>
                   <div className="text-center">
                      <p className="text-white font-black uppercase italic tracking-widest">Processando Protocolo...</p>
                      <p className="text-[10px] text-gray-500 font-bold uppercase mt-1">Isso pode levar alguns segundos dependendo da quantidade de imagens.</p>
                   </div>
                </div>
              ) : (
                <div className="space-y-6">
                   {uploadMode === 'single' ? (
                     <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
                        <div className="grid grid-cols-2 gap-4">
                           <div className="space-y-2">
                              <label className="text-[10px] font-black text-gray-600 uppercase italic ml-2">Nº do Capítulo</label>
                              <input 
                                type="number" 
                                value={newCap.number} 
                                onChange={e => setNewCap({...newCap, number: parseFloat(e.target.value)})}
                                className="w-full bg-[#0b0e14] border-none rounded-2xl py-4 px-6 font-bold text-white focus:ring-2 focus:ring-blue-500" 
                              />
                           </div>
                           <div className="space-y-2">
                              <label className="text-[10px] font-black text-gray-600 uppercase italic ml-2">Título (Opcional)</label>
                              <input 
                                placeholder="Ex: O Despertar"
                                value={newCap.title}
                                onChange={e => setNewCap({...newCap, title: e.target.value})}
                                className="w-full bg-[#0b0e14] border-none rounded-2xl py-4 px-6 font-bold text-white focus:ring-2 focus:ring-blue-500" 
                              />
                           </div>
                        </div>
                        
                        <div className="relative group">
                           <input 
                              type="file" 
                              multiple 
                              accept="image/*,application/pdf,.cbz,.zip"
                              onChange={e => e.target.files && processSingleFiles(e.target.files)}
                              className="absolute inset-0 opacity-0 cursor-pointer z-10" 
                           />
                           <div className={`py-12 border-2 border-dashed rounded-[2.5rem] flex flex-col items-center justify-center gap-4 transition-all ${newCap.contentUrl ? 'border-green-500 bg-green-500/5' : 'border-white/5 bg-[#0b0e14] group-hover:border-blue-500/50'}`}>
                              {newCap.contentUrl ? (
                                <>
                                  <CheckCircle2 size={48} className="text-green-500" />
                                  <p className="text-green-500 font-black text-xs uppercase italic tracking-widest">Conteúdo Preparado ({newCap.pages} pgs)</p>
                                </>
                              ) : (
                                <>
                                  <Upload size={48} className="text-gray-800" />
                                  <div className="text-center">
                                     <p className="text-gray-500 font-black text-xs uppercase italic tracking-widest">Selecionar Arquivos</p>
                                     <p className="text-[9px] text-gray-700 font-bold uppercase mt-1">Imagens, PDF ou CBZ</p>
                                  </div>
                                </>
                              )}
                           </div>
                        </div>

                        <button 
                          disabled={!newCap.contentUrl}
                          onClick={handleAddSingleChapter}
                          className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white font-black py-5 rounded-2xl text-xs uppercase italic tracking-[0.2em] shadow-xl shadow-blue-600/20 transition-all"
                        >
                          Confirmar Injeção
                        </button>
                     </div>
                   ) : (
                     <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                        <div className="bg-blue-600/10 border border-blue-500/20 p-6 rounded-3xl flex gap-4">
                           <AlertTriangle className="text-blue-500 shrink-0" />
                           <div className="space-y-1">
                              <p className="text-blue-500 font-black text-[10px] uppercase italic">Manual do Operativo</p>
                              <p className="text-[10px] text-gray-400 font-bold leading-relaxed">
                                Selecione uma pasta que contenha subpastas ou arquivos comprimidos (.cbz, .pdf). O sistema irá agrupar o conteúdo automaticamente por capítulo.
                              </p>
                           </div>
                        </div>

                        <div className="relative group">
                           <input 
                              type="file" 
                              multiple 
                              {...{ webkitdirectory: "", directory: "" } as any}
                              onChange={e => e.target.files && processBulkFolder(e.target.files)}
                              className="absolute inset-0 opacity-0 cursor-pointer z-10" 
                           />
                           <div className="py-20 border-2 border-dashed border-white/5 bg-[#0b0e14] rounded-[2.5rem] group-hover:border-blue-500/50 flex flex-col items-center justify-center gap-6 transition-all">
                              <div className="w-20 h-20 bg-blue-600/10 rounded-3xl flex items-center justify-center text-blue-500">
                                 <FolderOpen size={40} />
                              </div>
                              <div className="text-center">
                                 <p className="text-white font-black text-sm uppercase italic tracking-widest">Selecionar Pasta Raiz</p>
                                 <p className="text-[10px] text-gray-500 font-bold uppercase mt-2">Suporte a Subpastas e Arquivos Comprimidos</p>
                              </div>
                           </div>
                        </div>
                     </div>
                   )}
                </div>
              )}
           </div>
        </div>
      )}

      <style>{`.custom-reader-scroll::-webkit-scrollbar { width: 6px; } .custom-reader-scroll::-webkit-scrollbar-track { background: transparent; } .custom-reader-scroll::-webkit-scrollbar-thumb { background: #1a1d23; border-radius: 10px; } .custom-reader-scroll::-webkit-scrollbar-thumb:hover { background: #3b82f6; }`}</style>
    </div>
  );
};

export default LibraryPage;
