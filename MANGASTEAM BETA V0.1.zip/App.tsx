
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  Library, 
  User, 
  Search, 
  LayoutDashboard,
  PlusCircle,
  X,
  LogOut,
  Upload,
  Heart,
  Users,
  Trash2,
  Menu as MenuIcon,
  Settings,
  ChevronRight
} from 'lucide-react';
import Dashboard from './pages/Dashboard';
import LibraryPage from './pages/LibraryPage';
import ProfilePage from './pages/ProfilePage';
import ReaderView from './components/ReaderView';
import { UserProfile, MangaEntry, MediaType, MediaStatus, Chapter } from './types';
import { storageService } from './services/storageService';
import { getRankInfo } from './constants';

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    const activeId = localStorage.getItem('ms_active_user_id');
    if (!activeId) return null;
    const allUsers = JSON.parse(localStorage.getItem('ms_users_registry') || '{}');
    return allUsers[activeId] || null;
  });

  const [library, setLibrary] = useState<MangaEntry[]>([]);
  const [isLibraryLoaded, setIsLibraryLoaded] = useState(false);
  const [activeChapter, setActiveChapter] = useState<{mangaId: string, chapter: Chapter} | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Carregar biblioteca quando o usuário logar
  useEffect(() => {
    if (user) {
      const savedLibrary = localStorage.getItem(`ms_library_${user.id}`);
      const data: MangaEntry[] = savedLibrary ? JSON.parse(savedLibrary) : [];
      setLibrary(data.map(m => ({
        ...m,
        chapters: m.chapters.map(c => ({ ...c, contentUrl: '', pagesList: [] }))
      })));
      setIsLibraryLoaded(true);
    } else {
      setLibrary([]);
      setIsLibraryLoaded(false);
    }
  }, [user?.id]);

  // Persistir alterações (Apenas se a biblioteca já foi carregada para este usuário)
  useEffect(() => {
    if (user && isLibraryLoaded) {
      const allUsers = JSON.parse(localStorage.getItem('ms_users_registry') || '{}');
      allUsers[user.id] = user;
      localStorage.setItem('ms_users_registry', JSON.stringify(allUsers));
      localStorage.setItem('ms_active_user_id', user.id);

      const cleanLibrary = library.map(m => ({
        ...m,
        chapters: m.chapters.map(c => ({ ...c, contentUrl: '', pagesList: [] }))
      }));
      localStorage.setItem(`ms_library_${user.id}`, JSON.stringify(cleanLibrary));
    }
  }, [user, library, isLibraryLoaded]);

  const generateUserId = (username: string) => {
    // Sanitização rigorosa para evitar duplicatas por espaços ou letras maiúsculas
    return btoa(username.trim().toLowerCase()).substring(0, 16);
  };

  const handleAuth = (data: { username: string, email: string }) => {
    if (!data.username.trim()) return;

    const allUsers = JSON.parse(localStorage.getItem('ms_users_registry') || '{}');
    const userId = generateUserId(data.username);

    if (allUsers[userId]) {
      // Perfil existente detectado
      setUser(allUsers[userId]);
    } else {
      // Criar novo perfil
      const newUser: UserProfile = {
        id: userId,
        username: data.username.trim(),
        email: data.email || `${data.username.trim().toLowerCase()}@local.ms`,
        avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(data.username.trim())}`,
        level: 1,
        xp: 0,
        total_pages_read: 0,
        total_chapters_read: 0,
        total_titles: 0,
        bio: 'Operativo Local MangaSteam',
        created_at: new Date().toISOString(),
        featured_ids: []
      };
      
      // Salvar imediatamente no registro para evitar duplicatas em renderizações rápidas
      allUsers[userId] = newUser;
      localStorage.setItem('ms_users_registry', JSON.stringify(allUsers));
      setUser(newUser);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('ms_active_user_id');
    setUser(null);
    setLibrary([]);
    setIsLibraryLoaded(false);
    setIsMobileMenuOpen(false);
  };

  const deleteUserProfile = async (userId: string, skipConfirm = false) => {
    if (!skipConfirm && !confirm("⚠️ PROTOCOLO DE EXCLUSÃO CRÍTICO: Todos os dados deste perfil serão destruídos permanentemente.")) return false;
    
    // Limpar IndexedDB do usuário
    const savedLibrary = localStorage.getItem(`ms_library_${userId}`);
    if (savedLibrary) {
      try {
        const data: MangaEntry[] = JSON.parse(savedLibrary);
        for (const manga of data) {
          for (const cap of manga.chapters) await storageService.deleteChapterData(cap.id);
        }
      } catch (e) { console.error("Erro ao limpar cache do usuário:", e); }
    }

    // Limpar localStorage
    localStorage.removeItem(`ms_library_${userId}`);
    const allUsers = JSON.parse(localStorage.getItem('ms_users_registry') || '{}');
    delete allUsers[userId];
    localStorage.setItem('ms_users_registry', JSON.stringify(allUsers));
    
    if (user?.id === userId) handleLogout();
    window.dispatchEvent(new Event('storage'));
    return true;
  };

  const addManga = (manga: Omit<MangaEntry, 'id' | 'current_chapter' | 'chapters' | 'pages_read' | 'is_favorite'>) => {
    const newManga: MangaEntry = {
      ...manga,
      id: Math.random().toString(36).substr(2, 9),
      current_chapter: 0,
      chapters: [],
      pages_read: 0,
      is_favorite: false
    };
    setLibrary(prev => [...prev, newManga]);
    if (user) setUser({ ...user, total_titles: user.total_titles + 1 });
    setShowAddModal(false);
  };

  const deleteManga = async (mangaId: string) => {
    const manga = library.find(m => m.id === mangaId);
    if (!manga) return;
    for (const cap of manga.chapters) await storageService.deleteChapterData(cap.id);
    setLibrary(prev => prev.filter(m => m.id !== mangaId));
    if (user) setUser({ ...user, total_titles: Math.max(0, user.total_titles - 1) });
  };

  const deleteChapter = async (mangaId: string, chapterId: string) => {
    await storageService.deleteChapterData(chapterId);
    setLibrary(prev => prev.map(m => m.id === mangaId ? { ...m, chapters: m.chapters.filter(c => c.id !== chapterId) } : m));
  };

  const updateManga = (mangaId: string, updates: Partial<MangaEntry>) => {
    setLibrary(prev => prev.map(m => m.id === mangaId ? { ...m, ...updates } : m));
  };

  const addChapter = async (mangaId: string, chapter: Omit<Chapter, 'id'>) => {
    const newId = Math.random().toString(36).substr(2, 9);
    await storageService.saveChapterData(newId, { contentUrl: chapter.contentUrl, pagesList: chapter.pagesList });
    setLibrary(prev => prev.map(m => m.id === mangaId ? { ...m, chapters: [...m.chapters, { ...chapter, id: newId, contentUrl: '', pagesList: [] }] } : m));
  };

  const markAsRead = useCallback((mangaId: string, chapterId: string, pages: number) => {
    setLibrary(prev => prev.map(m => {
      if (m.id === mangaId) {
        const chapterIdx = m.chapters.findIndex(c => c.id === chapterId);
        if (chapterIdx !== -1 && !m.chapters[chapterIdx].read_at) {
          const updatedChapters = [...m.chapters];
          updatedChapters[chapterIdx] = { ...updatedChapters[chapterIdx], read_at: new Date().toISOString() };
          const xpGain = 25;
          if (user) {
            const newXp = user.xp + xpGain;
            setUser({
              ...user,
              total_chapters_read: user.total_chapters_read + 1,
              total_pages_read: user.total_pages_read + (pages || 20),
              xp: newXp,
              level: Math.floor(Math.sqrt(newXp / 100)) + 1
            });
          }
          return { ...m, chapters: updatedChapters, current_chapter: updatedChapters.filter(c => !!c.read_at).length, pages_read: m.pages_read + (pages || 20) };
        }
      }
      return m;
    }));
  }, [user]);

  const navigateChapter = useCallback((mangaId: string, direction: 'next' | 'prev') => {
    const manga = library.find(m => m.id === mangaId);
    if (!manga || !manga.chapters.length) return false;
    const sortedChapters = [...manga.chapters].sort((a, b) => a.number - b.number);
    const currentIndex = sortedChapters.findIndex(c => c.id === activeChapter?.chapter.id);
    if (direction === 'next' && currentIndex < sortedChapters.length - 1) {
      setActiveChapter({ mangaId, chapter: sortedChapters[currentIndex + 1] });
      return true;
    } else if (direction === 'prev' && currentIndex > 0) {
      setActiveChapter({ mangaId, chapter: sortedChapters[currentIndex - 1] });
      return true;
    }
    return false;
  }, [library, activeChapter]);

  const handleCompleteChapter = (pages: number) => {
    if (activeChapter) {
      markAsRead(activeChapter.mangaId, activeChapter.chapter.id, pages);
      const moved = navigateChapter(activeChapter.mangaId, 'next');
      if (!moved) setActiveChapter(null);
    }
  };

  const currentMangaInReader = useMemo(() => activeChapter ? library.find(m => m.id === activeChapter.mangaId) : null, [activeChapter, library]);
  const readerNavigation = useMemo(() => {
    if (!currentMangaInReader || !activeChapter) return { hasNext: false, hasPrev: false };
    const sorted = [...currentMangaInReader.chapters].sort((a, b) => a.number - b.number);
    const idx = sorted.findIndex(c => c.id === activeChapter.chapter.id);
    return { hasNext: idx < sorted.length - 1, hasPrev: idx > 0 };
  }, [currentMangaInReader, activeChapter]);

  if (!user) return <AuthPage onAuth={handleAuth} onDeleteProfile={deleteUserProfile} />;

  return (
    <Router>
      <div className="flex h-screen overflow-hidden bg-[#0b0e14] text-slate-200 font-sans flex-col lg:flex-row">
        
        {/* Desktop Sidebar */}
        <aside className="w-64 bg-[#11141b] border-r border-white/5 flex flex-col hidden lg:flex">
          <div className="p-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center font-black text-white shadow-lg italic">MS</div>
              <span className="text-xl font-black italic tracking-tighter uppercase">Steam<span className="text-blue-500">Read</span></span>
            </div>
          </div>
          <nav className="flex-1 px-4 space-y-1">
            <SidebarLink to="/" icon={<LayoutDashboard size={20} />} label="Início" />
            <SidebarLink to="/library" icon={<Library size={20} />} label="Minha Estante" />
            <SidebarLink to="/profile" icon={<User size={20} />} label="Meu Perfil" />
          </nav>
          <div className="p-4 mt-auto border-t border-white/5 bg-black/20">
            <div className="flex items-center gap-3 px-4 py-3 mb-2">
              <img src={user.avatar_url} className="w-8 h-8 rounded-lg bg-blue-600 border border-white/10" />
              <div className="overflow-hidden">
                <p className="text-[10px] font-black text-white uppercase italic truncate">{user.username}</p>
                <p className={`text-[8px] font-bold uppercase tracking-widest ${getRankInfo(user.total_chapters_read).color}`}>
                   {getRankInfo(user.total_chapters_read).title}
                </p>
              </div>
            </div>
            <button onClick={handleLogout} className="w-full flex items-center gap-3 px-5 py-3 rounded-xl text-gray-500 hover:text-white hover:bg-white/5 transition-all text-[10px] font-black uppercase italic">
              <LogOut size={16} /> Sair
            </button>
          </div>
        </aside>

        {/* Mobile Sidebar / Drawer Overlay */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm lg:hidden" onClick={() => setIsMobileMenuOpen(false)}>
            <div className="w-72 h-full bg-[#11141b] border-r border-white/10 p-6 flex flex-col animate-in slide-in-from-left duration-300" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-black text-white italic text-xs">MS</div>
                  <span className="text-lg font-black italic uppercase">MENU</span>
                </div>
                <button onClick={() => setIsMobileMenuOpen(false)} className="text-gray-500"><X /></button>
              </div>
              
              <div className="flex items-center gap-4 p-4 bg-black/30 rounded-2xl border border-white/5 mb-8">
                 <img src={user.avatar_url} className="w-12 h-12 rounded-xl border border-white/10" />
                 <div className="overflow-hidden">
                    <p className="text-white font-black text-sm uppercase italic truncate">{user.username}</p>
                    <p className={`text-[9px] font-bold uppercase ${getRankInfo(user.total_chapters_read).color}`}>
                       {getRankInfo(user.total_chapters_read).title}
                    </p>
                 </div>
              </div>

              <nav className="space-y-2 flex-1">
                 <MobileSidebarLink to="/" icon={<LayoutDashboard size={20}/>} label="Início" onClick={() => setIsMobileMenuOpen(false)} />
                 <MobileSidebarLink to="/library" icon={<Library size={20}/>} label="Estante" onClick={() => setIsMobileMenuOpen(false)} />
                 <MobileSidebarLink to="/profile" icon={<User size={20}/>} label="Perfil" onClick={() => setIsMobileMenuOpen(false)} />
              </nav>

              <div className="pt-6 border-t border-white/5">
                 <button onClick={handleLogout} className="w-full flex items-center justify-between p-4 bg-red-600/10 text-red-500 rounded-2xl font-black uppercase italic text-xs hover:bg-red-600 hover:text-white transition-all">
                    <div className="flex items-center gap-3"><LogOut size={18}/> Sair do Sistema</div>
                    <ChevronRight size={16}/>
                 </button>
              </div>
            </div>
          </div>
        )}

        {/* Mobile Bottom Nav Bar */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-[#11141b]/95 backdrop-blur-xl border-t border-white/5 flex justify-around items-center p-3 z-50">
          <MobileNavLink to="/" icon={<LayoutDashboard size={22} />} />
          <MobileNavLink to="/library" icon={<Library size={22} />} />
          <button onClick={() => setShowAddModal(true)} className="p-4 bg-blue-600 text-white rounded-2xl shadow-xl shadow-blue-600/20 active:scale-90 transition-all -translate-y-4 border-4 border-[#0b0e14]">
            <PlusCircle size={24} />
          </button>
          <MobileNavLink to="/profile" icon={<User size={22} />} />
          <button onClick={() => setIsMobileMenuOpen(true)} className="p-3 text-gray-500"><MenuIcon size={22}/></button>
        </nav>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto relative bg-[#0b0e14] pb-24 lg:pb-0">
          <header className="sticky top-0 z-30 flex items-center justify-between px-4 lg:px-8 py-4 bg-[#0b0e14]/80 backdrop-blur-xl border-b border-white/5">
            <div className="flex items-center gap-3 lg:hidden">
               <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 -ml-2 text-gray-400"><MenuIcon size={20}/></button>
               <span className="text-lg font-black italic tracking-tighter uppercase">Manga<span className="text-blue-500">Steam</span></span>
            </div>
            <div className="hidden lg:block relative flex-1 max-w-xl">
               <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
               <input placeholder="Buscar na estante local..." className="w-full bg-[#1a1d23] border-none rounded-2xl py-3 pl-12 pr-4 text-xs font-bold text-white focus:ring-2 focus:ring-blue-500 transition-all" />
            </div>
            <div className="flex items-center gap-4">
              <button onClick={() => setShowAddModal(true)} className="hidden lg:flex bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest items-center gap-2 shadow-xl shadow-blue-600/20 italic transition-all">
                <PlusCircle size={18} /> Novo Título
              </button>
              <img src={user.avatar_url} onClick={() => setIsMobileMenuOpen(true)} className="w-8 h-8 rounded-lg border border-white/10 cursor-pointer lg:hover:ring-2 lg:hover:ring-blue-500 transition-all" />
            </div>
          </header>

          <div className="p-4 lg:p-8 max-w-7xl mx-auto">
            <Routes>
              <Route path="/" element={<Dashboard user={user} library={library} onRead={(mId, cap) => setActiveChapter({mangaId: mId, chapter: cap})} />} />
              <Route path="/library" element={<LibraryPage library={library} onAddChapter={addChapter} onUpdateManga={updateManga} onDeleteManga={deleteManga} onDeleteChapter={deleteChapter} onRead={(mId, cap) => setActiveChapter({mangaId: mId, chapter: cap})} />} />
              <Route path="/profile" element={<ProfilePage user={user} library={library} onUpdateUser={setUser} onDeleteProfile={deleteUserProfile} />} />
            </Routes>
          </div>
        </main>

        {showAddModal && <AddMangaModal onAdd={addManga} onClose={() => setShowAddModal(false)} />}
        {activeChapter && currentMangaInReader && (
          <ReaderView 
            mangaTitle={currentMangaInReader.title}
            chapter={activeChapter.chapter} 
            hasNext={readerNavigation.hasNext}
            hasPrev={readerNavigation.hasPrev}
            onClose={() => setActiveChapter(null)} 
            onNext={() => navigateChapter(activeChapter.mangaId, 'next')}
            onPrev={() => navigateChapter(activeChapter.mangaId, 'prev')}
            onComplete={handleCompleteChapter}
          />
        )}
      </div>
    </Router>
  );
};

const SidebarLink: React.FC<{ to: string, icon: React.ReactNode, label: string }> = ({ to, icon, label }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <Link to={to} className={`flex items-center gap-4 px-6 py-4 rounded-2xl transition-all ${isActive ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20 font-black italic' : 'text-gray-500 hover:text-white hover:bg-white/5 font-bold'}`}>
      {icon} <span className="text-[11px] uppercase tracking-widest">{label}</span>
    </Link>
  );
};

const MobileSidebarLink: React.FC<{ to: string, icon: React.ReactNode, label: string, onClick: () => void }> = ({ to, icon, label, onClick }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <Link to={to} onClick={onClick} className={`flex items-center justify-between p-4 rounded-2xl transition-all ${isActive ? 'bg-blue-600 text-white shadow-lg font-black' : 'text-gray-400 hover:bg-white/5'}`}>
      <div className="flex items-center gap-3">{icon} <span className="text-xs uppercase italic tracking-widest">{label}</span></div>
      <ChevronRight size={14} className={isActive ? 'opacity-100' : 'opacity-30'} />
    </Link>
  );
};

const MobileNavLink: React.FC<{ to: string, icon: React.ReactNode }> = ({ to, icon }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <Link to={to} className={`p-3 rounded-2xl transition-all ${isActive ? 'bg-blue-600/10 text-blue-500' : 'text-gray-500'}`}>
      {icon}
    </Link>
  );
};

const AuthPage: React.FC<{ onAuth: any, onDeleteProfile: (id: string, skip: boolean) => Promise<any> }> = ({ onAuth, onDeleteProfile }) => {
  const [form, setForm] = useState({ username: '', email: '' });
  const [history, setHistory] = useState<UserProfile[]>([]);

  const loadHistory = useCallback(() => {
    const all = JSON.parse(localStorage.getItem('ms_users_registry') || '{}');
    setHistory(Object.values(all));
  }, []);

  useEffect(() => {
    loadHistory();
    const handleStorageChange = () => loadHistory();
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [loadHistory]);

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm("⚠️ ELIMINAR REGISTRO?")) {
      await onDeleteProfile(id, true);
      loadHistory();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.username.trim()) {
      onAuth(form);
    }
  };

  return (
    <div className="h-screen bg-[#0b0e14] flex items-center justify-center p-4 lg:p-6 overflow-hidden">
      <div className="w-full max-w-lg space-y-8 lg:space-y-12 relative z-10">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 lg:w-24 lg:h-24 bg-blue-600 rounded-[2rem] mx-auto flex items-center justify-center font-black text-4xl lg:text-5xl text-white shadow-2xl italic">MS</div>
          <h1 className="text-4xl lg:text-5xl font-black text-white italic uppercase tracking-tighter">Manga<span className="text-blue-500">Steam</span></h1>
        </div>
        <div className="bg-[#11141b] p-6 lg:p-10 rounded-[2.5rem] border border-white/5 shadow-2xl space-y-8">
          {history.length > 0 && (
            <div className="space-y-4">
              <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest flex items-center gap-2"><Users size={12}/> Perfis Detectados</p>
              <div className="grid grid-cols-2 gap-3 lg:gap-4 overflow-y-auto max-h-[200px] pr-2 custom-reader-scroll">
                {history.map(u => (
                  <div key={u.id} className="relative group">
                    <button onClick={() => onAuth({ username: u.username, email: u.email })} className="w-full flex items-center gap-2 lg:gap-3 p-3 lg:p-4 bg-[#0b0e14] border border-white/5 rounded-2xl hover:border-blue-500/50 transition-all text-left group">
                      <img src={u.avatar_url} className="w-8 h-8 lg:w-10 lg:h-10 rounded-xl bg-blue-600" />
                      <div className="overflow-hidden">
                         <p className="text-white font-black text-[10px] lg:text-xs uppercase italic truncate">{u.username}</p>
                      </div>
                    </button>
                    <button onClick={(e) => handleDelete(e, u.id)} className="absolute -top-1 -right-1 p-2 bg-red-600 text-white rounded-full shadow-xl z-30 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={10} /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4 pt-4 border-t border-white/5">
            <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Acesso de Novo Operativo</p>
            <input 
              placeholder="Digite seu Login" 
              required
              value={form.username}
              onChange={e => setForm({...form, username: e.target.value})} 
              className="w-full bg-[#0b0e14] border border-white/5 rounded-2xl py-4 px-6 text-white font-bold outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <button type="submit" className="w-full bg-blue-600 text-white font-black py-4 lg:py-5 rounded-2xl shadow-xl uppercase text-xs italic tracking-widest transition-all hover:bg-blue-500 active:scale-95">Sincronizar Protocolo</button>
          </form>
        </div>
      </div>
    </div>
  );
};

const AddMangaModal: React.FC<{ onAdd: any, onClose: any }> = ({ onAdd, onClose }) => {
  const [data, setData] = useState({ title: '', type: MediaType.MANGA, cover_url: '', total_chapters: 1, status: MediaStatus.LENDO, rating: 5 });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setData({ ...data, cover_url: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 lg:p-6 bg-black/95 backdrop-blur-xl">
      <div className="bg-[#11141b] w-full max-w-xl rounded-[2.5rem] lg:rounded-[3rem] border border-white/5 shadow-2xl p-6 lg:p-10 space-y-6 overflow-y-auto max-h-[90vh] custom-reader-scroll">
        <div className="flex items-center justify-between">
           <h2 className="text-xl lg:text-2xl font-black text-white italic uppercase tracking-tighter">Registrar Nova Obra</h2>
           <button onClick={onClose} className="text-gray-500"><X/></button>
        </div>
        <div className="flex flex-col sm:flex-row gap-6 lg:gap-8">
           <div className="w-full sm:w-40 aspect-[3/4] bg-[#0b0e14] rounded-3xl border-2 border-dashed border-white/5 flex flex-col items-center justify-center relative overflow-hidden shrink-0">
              {data.cover_url ? <img src={data.cover_url} className="w-full h-full object-cover" /> : <Upload className="text-gray-700" />}
              <p className="text-[9px] font-black text-gray-700 mt-2 uppercase">Capa</p>
              <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleFileUpload} />
           </div>
           <div className="flex-1 space-y-4">
              <div className="space-y-1">
                 <label className="text-[9px] font-black text-gray-600 uppercase italic ml-2">Título da Obra</label>
                 <input placeholder="Ex: Solo Leveling" value={data.title} onChange={e => setData({...data, title: e.target.value})} className="w-full bg-[#0b0e14] border-none rounded-2xl py-4 px-5 font-bold text-white focus:ring-2 focus:ring-blue-500" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[9px] font-black text-gray-600 uppercase italic ml-2">Protocolo</label>
                  <select value={data.type} onChange={e => setData({...data, type: e.target.value as any})} className="w-full bg-[#0b0e14] border-none rounded-2xl py-4 px-5 font-bold text-white text-xs uppercase italic outline-none">
                    {Object.values(MediaType).map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[9px] font-black text-gray-600 uppercase italic ml-2">Caps Totais</label>
                  <input type="number" placeholder="0" value={data.total_chapters} onChange={e => setData({...data, total_chapters: parseInt(e.target.value) || 0})} className="w-full bg-[#0b0e14] border-none rounded-2xl py-4 px-5 font-bold text-white text-xs" />
                </div>
              </div>
           </div>
        </div>
        <div className="flex gap-4 pt-4">
          <button onClick={onClose} className="flex-1 bg-[#1a1d23] text-gray-500 font-black py-5 rounded-2xl text-[10px] uppercase italic">Cancelar</button>
          <button onClick={() => onAdd(data)} className="flex-1 bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl uppercase italic text-[10px] hover:bg-blue-500 transition-all">Salvar Localmente</button>
        </div>
      </div>
    </div>
  );
};

export default App;
