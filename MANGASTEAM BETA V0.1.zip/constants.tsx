
import { Achievement, UserProfile } from './types';

export const ACHIEVEMENTS: Achievement[] = [
  { 
    id: '1', 
    name: 'Primeiro Passo', 
    description: 'Adicionou o primeiro título à biblioteca', 
    icon: '📚', 
    rarity: 'Comum',
    requirement: (u) => u.total_titles >= 1
  },
  { 
    id: '2', 
    name: 'Mestre dos Capítulos', 
    description: 'Leu 100 capítulos no total', 
    icon: '⚡', 
    rarity: 'Raro',
    requirement: (u) => u.total_chapters_read >= 100 
  },
  { 
    id: '3', 
    name: 'Rato de Biblioteca', 
    description: 'Leu mais de 1000 páginas', 
    icon: '📖', 
    rarity: 'Épico',
    requirement: (u) => u.total_pages_read >= 1000
  },
  { 
    id: '4', 
    name: 'Lendário', 
    description: 'Completou 50 séries na estante', 
    icon: '👑', 
    rarity: 'Lendário',
    requirement: (u) => u.total_titles >= 50
  },
  { 
    id: '5', 
    name: 'Devorador de Manhwas', 
    description: 'Processou mais de 5.000 capítulos', 
    icon: '🔥', 
    rarity: 'Lendário',
    requirement: (u) => u.total_chapters_read >= 5000
  },
  { 
    id: '6', 
    name: 'Divindade S-Rank', 
    description: 'Ultrapassou o limiar de 15.000 capítulos lidos', 
    icon: '💎', 
    rarity: 'Divino',
    requirement: (u) => u.total_chapters_read >= 15000
  },
];

export const getRankInfo = (chapters: number) => {
  if (chapters >= 15000) return { title: 'Divindade S-Rank', color: 'text-amber-400', aura: 'shadow-[0_0_30px_rgba(251,191,36,0.4)]', insignia: '❂' };
  if (chapters >= 10000) return { title: 'Lenda Viva', color: 'text-purple-500', aura: 'shadow-[0_0_20px_rgba(168,85,247,0.3)]', insignia: '✯' };
  if (chapters >= 5000) return { title: 'Comandante', color: 'text-red-500', aura: 'shadow-[0_0_15px_rgba(239,68,68,0.2)]', insignia: '⌘' };
  if (chapters >= 2000) return { title: 'Elite', color: 'text-blue-500', aura: '', insignia: '⚙' };
  if (chapters >= 500) return { title: 'Veterano', color: 'text-green-500', aura: '', insignia: '⚔' };
  if (chapters >= 100) return { title: 'Operativo', color: 'text-slate-300', aura: '', insignia: '⛨' };
  return { title: 'Recruta', color: 'text-gray-500', aura: '', insignia: '🔰' };
};
